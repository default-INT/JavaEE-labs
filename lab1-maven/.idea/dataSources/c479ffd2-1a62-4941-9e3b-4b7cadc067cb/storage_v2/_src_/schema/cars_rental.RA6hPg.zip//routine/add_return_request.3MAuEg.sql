create
    definer = root@localhost procedure add_return_request(IN var_return_date datetime, IN var_order_id int,
                                                          IN var_description varchar(200),
                                                          IN var_return_mark tinyint(1), IN var_repair_cost double)
BEGIN
    INSERT INTO return_requests(return_date, order_id, description, return_mark, repair_cost)
    VALUES (var_return_date, var_order_id, var_description, var_return_mark, var_repair_cost);
END;

