create
    definer = root@localhost procedure delete_account(IN var_id int)
BEGIN
    DELETE FROM accounts WHERE id = var_id;
END;

