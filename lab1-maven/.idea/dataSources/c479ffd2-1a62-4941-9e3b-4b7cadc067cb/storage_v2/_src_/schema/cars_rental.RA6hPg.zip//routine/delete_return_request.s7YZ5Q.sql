create
    definer = root@localhost procedure delete_return_request(IN var_return_req_id int)
BEGIN
    DELETE FROM return_requests WHERE id = var_return_req_id;
END;

