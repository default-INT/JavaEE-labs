create
    definer = root@localhost procedure edit_order(IN var_order_id int, IN var_order_date datetime,
                                                  IN var_rental_period int, IN var_client_id int, IN var_car_id int,
                                                  IN var_passport_data varchar(40), IN var_price double,
                                                  IN var_closed tinyint(1))
BEGIN
    UPDATE orders SET
                      order_date = var_order_date,
                      rental_period = var_rental_period,
                      return_date = DATE_ADD(var_order_date, INTERVAL var_rental_period HOUR),
                      client_id = var_client_id,
                      car_id = var_car_id,
                      passport_data = var_passport_data,
                      price = var_price,
                      closed = var_closed
    WHERE id = var_order_id;
END;

