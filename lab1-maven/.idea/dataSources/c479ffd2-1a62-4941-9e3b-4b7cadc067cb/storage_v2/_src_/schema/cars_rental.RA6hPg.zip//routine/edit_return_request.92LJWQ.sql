create
    definer = root@localhost procedure edit_return_request(IN var_return_req_id int, IN var_return_date datetime,
                                                           IN var_order_id int, IN var_description varchar(200),
                                                           IN var_return_mark tinyint(1), IN var_repair_cost double)
BEGIN
    UPDATE return_requests SET
       return_date = var_return_date,
       order_id = var_order_id,
       description = var_description,
       return_mark = var_return_mark,
       repair_cost = var_repair_cost
    WHERE id = var_return_req_id;
    IF (var_return_mark = true) THEN
        UPDATE cars SET available = true
        WHERE id = (SELECT car_id FROM orders WHERE id = var_order_id);
    END IF;
END;

