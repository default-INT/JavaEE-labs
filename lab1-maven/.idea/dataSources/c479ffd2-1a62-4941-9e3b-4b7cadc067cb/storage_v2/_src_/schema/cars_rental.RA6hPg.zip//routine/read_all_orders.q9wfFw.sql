create
    definer = root@localhost procedure read_all_orders()
BEGIN
    SELECT * FROM orders;
END;

