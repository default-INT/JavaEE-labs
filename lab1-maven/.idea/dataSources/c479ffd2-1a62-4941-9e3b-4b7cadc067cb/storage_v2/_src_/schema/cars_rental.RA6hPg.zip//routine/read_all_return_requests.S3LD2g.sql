create
    definer = root@localhost procedure read_all_return_requests()
BEGIN
   SELECT * FROM return_requests;
END;

