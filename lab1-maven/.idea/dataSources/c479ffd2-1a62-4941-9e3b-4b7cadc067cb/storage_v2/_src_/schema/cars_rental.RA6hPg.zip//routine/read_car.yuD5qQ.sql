create
    definer = root@localhost procedure read_car(IN var_id int)
BEGIN
    SELECT * FROM cars WHERE id = var_id;
END;

