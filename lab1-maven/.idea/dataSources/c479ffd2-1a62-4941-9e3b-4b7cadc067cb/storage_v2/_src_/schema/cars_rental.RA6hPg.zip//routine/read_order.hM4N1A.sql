create
    definer = root@localhost procedure read_order(IN var_order_id int)
BEGIN
    SELECT * FROM orders WHERE id = var_order_id;
END;

