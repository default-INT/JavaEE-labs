create
    definer = root@localhost procedure read_return_request(IN var_return_req_id int)
BEGIN
    SELECT * FROM return_requests WHERE id = var_return_req_id;
END;

