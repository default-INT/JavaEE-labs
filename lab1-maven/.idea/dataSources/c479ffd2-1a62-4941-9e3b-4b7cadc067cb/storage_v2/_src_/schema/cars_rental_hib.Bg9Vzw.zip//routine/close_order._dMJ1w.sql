create
    definer = root@localhost procedure close_order(IN var_order_id int, IN var_return_date datetime)
BEGIN
    UPDATE orders SET closed = true
    WHERE id = var_order_id;
    CALL add_return_request(var_return_date, var_order_id, null, false, 0);
END;

