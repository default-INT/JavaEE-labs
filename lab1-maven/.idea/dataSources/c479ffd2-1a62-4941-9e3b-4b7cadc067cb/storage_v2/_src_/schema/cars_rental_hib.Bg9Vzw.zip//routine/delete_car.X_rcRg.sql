create
    definer = root@localhost procedure delete_car(IN var_id int)
BEGIN
    DELETE FROM cars WHERE id = var_id;
END;

