create
    definer = root@localhost procedure edit_car(IN var_id int, IN var_number varchar(10), IN var_model varchar(50),
                                                IN var_mileage int, IN var_year_of_issue int, IN var_price_hour int,
                                                IN var_transmission_id int, IN var_fuel_type_id int)
BEGIN
    UPDATE cars SET
                    number = var_number,
                    model = var_model,
                    mileage = var_mileage,
                    year_of_issue = var_year_of_issue,
                    price_hour = var_price_hour,
                    transmission_id = var_transmission_id,
                    fuel_type_id = var_fuel_type_id
    WHERE id = var_id;
END;

