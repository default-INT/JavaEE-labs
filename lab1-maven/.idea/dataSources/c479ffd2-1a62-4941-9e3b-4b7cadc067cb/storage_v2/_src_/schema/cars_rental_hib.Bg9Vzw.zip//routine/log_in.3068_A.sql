create
    definer = root@localhost procedure log_in(IN var_login varchar(16), IN var_password varchar(50))
BEGIN
    SELECT * FROM accounts WHERE login = var_login AND password = var_password;
END;

