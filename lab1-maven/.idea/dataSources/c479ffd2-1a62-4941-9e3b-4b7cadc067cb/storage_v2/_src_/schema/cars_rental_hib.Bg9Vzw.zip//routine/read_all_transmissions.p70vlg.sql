create
    definer = root@localhost procedure read_all_transmissions()
BEGIN
    SELECT * FROM transmissions;
END;

