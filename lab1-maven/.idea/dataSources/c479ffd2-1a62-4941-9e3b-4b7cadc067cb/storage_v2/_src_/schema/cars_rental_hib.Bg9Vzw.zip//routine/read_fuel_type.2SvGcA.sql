create
    definer = root@localhost procedure read_fuel_type(IN var_id int)
BEGIN
    SELECT * FROM fuel_types WHERE id = var_id;
END;

