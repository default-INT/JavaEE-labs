create
    definer = root@localhost procedure read_transmission(IN var_id int)
BEGIN
    SELECT * FROM transmissions WHERE id = var_id;
END;

